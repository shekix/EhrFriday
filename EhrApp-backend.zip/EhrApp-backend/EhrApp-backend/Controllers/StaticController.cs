﻿using Infrastructure.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EhrApp_backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StaticController : ControllerBase
    {
        private readonly StaticService _staticService;
        public StaticController(StaticService staticService)
        {
            _staticService = staticService;
        }

        [HttpGet("countries")]
        public async Task<IActionResult> Countries()
        {
            var result = await _staticService.Countries();
            return Ok(result);
        }

        [HttpGet("States")]
        public async Task<IActionResult> States(int id)
        {
            var result = await _staticService.States(id);
            return Ok(result);
        }

        [HttpGet("userType")]
        public async Task<IActionResult> userType()
        {
            var result = await _staticService.UserTypes();
            return Ok(result);
        }

        [HttpGet("Gender")]
        public async Task<IActionResult> Gender()
        {
            var result = await _staticService.Genders();
            return Ok(result);
        }

        [HttpGet("BloodGroup")]
        public async Task<IActionResult> BloodGroups()
        {
            var result = await _staticService.BloodGroups();
            return Ok(result);
        }

        [HttpGet("Qualification")]
        public async Task<IActionResult> Qualification()
        {
            var result = await _staticService.Qualifications();
            return Ok(result);
        }

        [HttpGet("Specialization")]
        public async Task<IActionResult> Specialization()
        {
            var result = await _staticService.Specializations();
            return Ok(result);
        }

    }
}
