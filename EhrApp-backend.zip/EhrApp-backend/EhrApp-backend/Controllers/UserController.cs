﻿using Core.Models.User;
using Infrastructure.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EhrApp_backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        public RegistrationLoginService _registrationService;
      
        public UserController(RegistrationLoginService registrationService)
        {
            _registrationService = registrationService;

        }

        [HttpPost("Register")]
        public async Task<IActionResult> userRegistration([FromForm] userRegistrationDto dto)
        {
            var result = await _registrationService.userRegistration(dto);
            if (result != null)
            {
                return Ok(result);
            }
            return Conflict("user with this email already exists");
        }


        [HttpPost("Login")]
        public async Task<IActionResult> userLogin(userLoginDto dto)
        {
            var result = await _registrationService.userLogin(dto);
            if (result)
            {
                return Ok("Successful");
            }
            return Unauthorized("unsuccessfulLogin");
        }

        [HttpPost("2FA")]
        public async Task<IActionResult> userVerification(OtpVerficationDto dto)
        {
            var result = await _registrationService.userVerification(dto);
            if (result == "unsuccessful")
            {
                return BadRequest("unsuccessful");
            }
            return Ok(result);
        }

        [HttpPost("ForgotPass")]
        public async Task<IActionResult> forgotPass(string email)
        {
            var result = await _registrationService.forgotPassword(email);
            if (result == "unsuccessful")
            {
                return NotFound(email);
            }
            return Ok(result);
        }
    }
}
