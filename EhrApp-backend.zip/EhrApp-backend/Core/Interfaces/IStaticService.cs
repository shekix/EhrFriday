﻿using Domain.Provider;
using Domain.StateCity;
using Domain.User;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Interfaces
{
    public interface IStaticService
    {
        Task<IEnumerable<Country>> Countries();
        Task<IEnumerable<State>> States(int id);
        Task<IEnumerable<userType>> UserTypes();
        Task<IEnumerable<Gender>> Genders();
        Task<IEnumerable<BloodGroup>> BloodGroups();
        Task<IEnumerable<Qualification>> Qualifications();
        Task<IEnumerable<Specialization>> Specializations();

    }
}
