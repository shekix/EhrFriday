﻿using Core.Models.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Interfaces
{
    public interface IRegistrationLoginService
    {
        Task<userRegistrationDto> userRegistration(userRegistrationDto dto);
        Task<bool> userLogin(userLoginDto dto);
        Task<string> userVerification(OtpVerficationDto dto);
        Task<string> forgotPassword(string email);
    }
}
