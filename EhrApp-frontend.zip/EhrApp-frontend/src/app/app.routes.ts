import { Routes } from '@angular/router';
import { MainComponent } from '../components/main/main.component';
import { RegistrationComponent } from '../components/registration/registration.component';
import { LoginComponent } from '../components/login/login.component';

export const routes: Routes = [
    {
        path:"",
        component:MainComponent
    },
    {
        path:"register",
        component:RegistrationComponent
    },
    {
        path:"login",
        component:LoginComponent
    }
];
