import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-main',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './main.component.html',
  styleUrl: './main.component.css'
})
export class MainComponent {

  setRoleProvider(){
    if(sessionStorage.getItem('role')){
      sessionStorage.removeItem('role')
    }

    sessionStorage.setItem('role','Provider');
  }

  setRolePatient(){
    if(sessionStorage.getItem('role')){
      sessionStorage.removeItem('role')
    }
    sessionStorage.setItem('role','Patient');
  }

}
